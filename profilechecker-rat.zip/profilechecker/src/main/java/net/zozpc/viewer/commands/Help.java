package net.zozpc.viewer.commands;

import com.google.common.collect.ImmutableList;
import net.minecraft.client.Minecraft;
import net.minecraft.command.ICommand;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.BlockPos;
import net.zozpc.viewer.utils.Messages;
import sun.tools.jconsole.Tab;

import java.awt.*;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.List;

public class Help implements ICommand {

    public static final String COMMAND_NAME = "pvhelp";
    private static final String COMMAND_USAGE = "/pvhelp";
    private static final List<String> ALIASES = ImmutableList.of("pvhelp");
    private static final List<String> TABS = Arrays.asList("pvhelp");

    @Override
    public String getCommandName() {
        return COMMAND_NAME;
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return COMMAND_USAGE;
    }

    @Override
    public List<String> getCommandAliases() {
        return ALIASES;
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        switch (args.length) {
            case 0:
                Messages.send("&cIncorrect command usage. Try " + getCommandUsage(sender));
                break;
            case 1:
                Messages.send("Command list: ");
                Messages.send("Commands: /hyauctions (playername)");
                Messages.send("Commands: /viewer (playername)");
                break;
        }
    }

    @Override
    public boolean canCommandSenderUseCommand(ICommandSender sender) {
        return true;
    }

    @Override
    public List<String> addTabCompletionOptions(ICommandSender iCommandSender, String[] strings, BlockPos blockPos) {
        return TABS;
    }

    @Override
    public boolean isUsernameIndex(String[] args, int index) {
        return false;
    }

    @Override
    public int compareTo(ICommand o) {
        return 0;
    }
}
