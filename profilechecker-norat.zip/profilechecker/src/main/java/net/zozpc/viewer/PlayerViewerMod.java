package net.zozpc.viewer;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.*;
import net.zozpc.viewer.proxy.IProxy;
import net.zozpc.viewer.utils.Reference;

@Mod(
        modid = Reference.MOD_ID,
        name = Reference.NAME,
        version = Reference.VERSION,
        acceptedMinecraftVersions = Reference.ACCEPTED_VERSIONS
)
public class PlayerViewerMod {

    @SidedProxy(

            clientSide = Reference.CLIENT_PROXY,

            serverSide = Reference.SERVER_PROXY
    )
    private static IProxy PROXY;

    @EventHandler
    public void onFMLPreInitialization(FMLPreInitializationEvent event) {
        PROXY.preInit(event);
    }

    @EventHandler
    public void onFMLInitialization(FMLInitializationEvent event) {
        PROXY.init(event);
    }

    @EventHandler
    public void onFMLPostInitialization(FMLPostInitializationEvent event) {
        PROXY.postInit(event);
    }

    @EventHandler
    public void onFMLServerStarting(FMLServerStartingEvent event) {
        PROXY.serverStarting(event);
    }

}
