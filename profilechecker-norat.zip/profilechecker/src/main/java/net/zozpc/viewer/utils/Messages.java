package net.zozpc.viewer.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;

public class Messages {

    private static final String PREFIX = Color.format("&9[&bPlayerViewer&9] ");

    public static void send(String text, String... args) {
        if (Minecraft.getMinecraft().thePlayer == null) {
            return;
        }
        text = String.format(text, (Object[]) args);
        StringBuilder messageBuilder = new StringBuilder();
        for (String word : text.split(" ")) {
            word = Color.format(Color.getLastColors(text) + word);
            messageBuilder.append(word).append(" ");
        }
        Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText(PREFIX + Color.format(messageBuilder.toString().trim())));
    }
}
