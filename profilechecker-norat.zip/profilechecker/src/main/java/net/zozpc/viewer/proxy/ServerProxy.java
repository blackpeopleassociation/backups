package net.zozpc.viewer.proxy;

import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.zozpc.viewer.commands.HyAuctions;
import net.zozpc.viewer.commands.ProfileViewer;

public class ServerProxy implements IProxy {

    @Override
    public void preInit(FMLPreInitializationEvent event) {
        ClientCommandHandler.instance.registerCommand(new HyAuctions());
        ClientCommandHandler.instance.registerCommand(new ProfileViewer());
    }

    @Override
    public void init(FMLInitializationEvent event) {}

    @Override
    public void postInit(FMLPostInitializationEvent event) {}

    @Override
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new HyAuctions());
        event.registerServerCommand(new ProfileViewer());
    }

}