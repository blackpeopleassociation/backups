package net.zozpc.viewer.utils;

public class Reference {

    public static final String MOD_ID = "playerviewer";

    public static final String NAME = "Player Viewer";

    public static final String VERSION = "1.0";

    public static final String ACCEPTED_VERSIONS = "[1.8.9]";

    public static final String CLIENT_PROXY = "net.zozpc.viewer.proxy.ClientProxy";

    public static final String SERVER_PROXY = "net.zozpc.viewer.proxy.ServerProxy";
}
