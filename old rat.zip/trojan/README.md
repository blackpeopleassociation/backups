# Example mod Template
This repository consists of the current code template that all of my upcoming mods will be built on. This is up to change.

All of the classes are claimed under the **[Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0)**. You're always free to change it to your own license (e.g GNU General Public License, MIT License, etc.) 

Feel free to use it in your mod if you'd like to, however please leave some credits as it would be highly appreciated.


