package net.reflxction.example.proxy;

public interface IMinecraft
{
    void execute() throws Exception;
}
